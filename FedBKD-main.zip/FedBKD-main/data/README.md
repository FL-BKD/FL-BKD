# Data

The CIFAR-10, CIFAR-100 and MNIST datasets will be downloaded automatically by the torchvision package.

The FEMNIST and Sent140 must be downloaded through LEAF https://github.com/TalwalkarLab/leaf.
